#参数配置
Redis_taskAdd_keyname = "pika_redis_add_key"
dingding_report_url = "https://oapi.dingtalk.com/robot/send?access_token=" \
                      "8bd600ae38ececa20cdde5e6d9768e13fcd58e17a5fa1eb5b5cc899f4dd596e7"
Fastapi_taskAdd_url = "http://127.0.0.1:8080/add/"
Fastapi_taskStatus_url = "http://127.0.0.1:8080/setstatus/"

#功能开关
Enable_Redis = False #True
pika_host = '192.168.60.168'


pika_port = 5672
pika_login = "test"
pika_password = "ximalayatest"