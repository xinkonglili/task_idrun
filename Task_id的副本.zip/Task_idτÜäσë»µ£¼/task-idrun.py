#!/usr/bin/env python
from starlette.requests import Request
from starlette.responses import JSONResponse


from fastapi import FastAPI
import uvicorn
import task_process


app = FastAPI()


task_manager = task_process.Taskmanager()

@app.get("/")
async def root():
    task_manager.start()
    return {"message": "Hello World"}

@app.get("/add/{task_id}/")
async def item_id(task_id: int):
    task_manager.start()
    task_manager.add_task(task_id)
    return {'Add task_id:': task_id}

@app.get("/setstatus/{task_id}={task_status}/")
async def item_id(task_id: int, task_status: int):
    task_manager.set_task_status(task_id, task_status)
    return {'task_id': task_id, "task_status": task_status}

@app.get("/health")
def health(request: Request):
    #log.info(f"health! client:{request.client}")
    return JSONResponse(content={"health": True})

@app.get("/task-idrun/healthcheck")
def healthcheck(request: Request):
    #log.info(f"healthcheck! client:{request.client}")
    # https://notes.dingtalk.com/doc/Y7kmblNWEMZnqzLq
    return JSONResponse(content={"ret": 200, "data": None, "msg": "ok"})


if __name__ == '__main__':
    #start fastapi
    uvicorn.run("task-idrun:app", port=8080, reload=True)

